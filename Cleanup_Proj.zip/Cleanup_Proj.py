bl_info = {
    "name": "Quick Mesh Cleanup+",
    "author": "ProJYeet",
    "version": (1, 0),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar > Quick Cleanup+",
    "description": "Enhanced one-click mesh cleanup for multiple selected objects (Shortcut: Alt+Ctrl+Q)",
    "category": "Mesh",
}

import bpy
import math
import bmesh

addon_keymaps = []  # Keymap storage for unregister


# ----------------------------------------------------------
# Operator
# ----------------------------------------------------------
class MESH_OT_quick_cleanup_plus(bpy.types.Operator):
    """Run cleanup operations on all selected meshes"""
    bl_idname = "mesh.quick_cleanup_plus"
    bl_label = "Run Quick Cleanup+"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        selected_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']

        if not selected_objects:
            self.report({'ERROR'}, "No mesh objects selected.")
            return {'CANCELLED'}

        original_active = context.object
        original_mode = context.mode

        for obj in selected_objects:
            context.view_layer.objects.active = obj
            obj.select_set(True)
            bpy.ops.object.mode_set(mode='EDIT')

            if scene.qmc_select_all:
                bpy.ops.mesh.select_all(action='SELECT')

            if scene.qmc_merge_vertices:
                bpy.ops.mesh.remove_doubles(threshold=scene.qmc_merge_distance)

            if scene.qmc_dissolve_limited:
                dissolve_angle = math.radians(scene.qmc_dissolve_angle)
                bpy.ops.mesh.dissolve_limited(angle_limit=dissolve_angle)

            if scene.qmc_tris_to_quads:
                bpy.ops.mesh.tris_convert_to_quads()

            if scene.qmc_delete_loose:
                bpy.ops.mesh.delete_loose()

            # --- Normals ---
            if scene.qmc_recalc_normals:
                me = obj.data
                bm = bmesh.from_edit_mesh(me)
                bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
                if scene.qmc_recalc_inside:
                    for f in bm.faces:
                        f.normal_flip()
                bm.normal_update()
                bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

            if scene.qmc_reset_vectors:
                bpy.ops.mesh.customdata_custom_splitnormals_clear()

            bpy.ops.object.mode_set(mode='OBJECT')

            # --- Shading ---
            if scene.qmc_shade_mode == 'SMOOTH':
                bpy.ops.object.shade_smooth()
            elif scene.qmc_shade_mode == 'FLAT':
                bpy.ops.object.shade_flat()
            elif scene.qmc_shade_mode == 'AUTO':
                bpy.ops.object.shade_smooth()
                if obj.type == 'MESH':
                    obj.data.shade_smooth()
                    if hasattr(obj.data, "use_auto_smooth"):
                        obj.data.use_auto_smooth = True
                    if hasattr(obj.data, "auto_smooth_angle"):
                        obj.data.auto_smooth_angle = 1.0472


            # --- Origin ---
            if scene.qmc_origin_mode == 'GEOMETRY':
                bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
            elif scene.qmc_origin_mode == 'OBJECT':
                bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS', center='BOUNDS')

        # --- Restore selections ---
        bpy.ops.object.select_all(action='DESELECT')
        for obj in selected_objects:
            obj.select_set(True)

        if original_active:
            bpy.context.view_layer.objects.active = original_active

        if original_mode.startswith('EDIT_'):
            bpy.ops.object.mode_set(mode='EDIT')
        else:
            bpy.ops.object.mode_set(mode=original_mode)

        # --- View Selected ---
        if scene.qmc_view_selected:
            for window in bpy.context.window_manager.windows:
                screen = window.screen
                for area in screen.areas:
                    if area.type == 'VIEW_3D':
                        for region in area.regions:
                            if region.type == 'WINDOW':
                                with bpy.context.temp_override(
                                        window=window,
                                        screen=screen,
                                        area=area,
                                        region=region,
                                        space=area.spaces.active,
                                        scene=context.scene,
                                        view_layer=context.view_layer):

                                    bpy.ops.view3d.view_selected(use_all_regions=False)
                                break
                        break

        self.report({'INFO'}, f"Quick Cleanup+ completed for {len(selected_objects)} selected meshes.")
        return {'FINISHED'}


# ----------------------------------------------------------
# Panel
# ----------------------------------------------------------
class VIEW3D_PT_quick_cleanup_plus(bpy.types.Panel):
    """Panel in the 3D Viewport sidebar"""
    bl_label = "Quick Cleanup+"
    bl_idname = "VIEW3D_PT_quick_cleanup_plus"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Quick Cleanup+'

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        col = layout.column(align=True)

        col.label(text="Topology Cleanup:")
        col.prop(scene, "qmc_select_all")
        col.prop(scene, "qmc_merge_vertices")
        if scene.qmc_merge_vertices:
            col.prop(scene, "qmc_merge_distance")

        col.prop(scene, "qmc_dissolve_limited")
        if scene.qmc_dissolve_limited:
            col.prop(scene, "qmc_dissolve_angle")

        col.prop(scene, "qmc_tris_to_quads")
        col.prop(scene, "qmc_delete_loose")

        col.separator()
        col.label(text="Normals/Data Cleanup:")
        col.prop(scene, "qmc_recalc_normals")
        if scene.qmc_recalc_normals:
            col.prop(scene, "qmc_recalc_inside", text="Recalculate Inside")
        col.prop(scene, "qmc_reset_vectors")

        col.separator()
        col.label(text="Origin and Shading:")
        col.prop(scene, "qmc_origin_mode", text="Set Origin")
        col.prop(scene, "qmc_shade_mode", text="Shade Mode")

        col.separator()
        col.label(text="Viewport:")
        col.prop(scene, "qmc_view_selected", text="View Selected After Cleanup")

        layout.separator()
        layout.operator("mesh.quick_cleanup_plus", text="Run Cleanup+", icon="CHECKMARK")
        layout.label(text="Shortcut: Alt + Ctrl + Q")


# ----------------------------------------------------------
# Keymap Handling (Alt+Ctrl+Q)
# ----------------------------------------------------------
def register_keymap():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if not kc:
        return

    try:
        km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
        kmi = km.keymap_items.new("mesh.quick_cleanup_plus", 'Q', 'PRESS', alt=True, ctrl=True)
        addon_keymaps.append((km, kmi))
    except Exception:
        pass


def unregister_keymap():
    for km, kmi in addon_keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    addon_keymaps.clear()


# ----------------------------------------------------------
# Registration
# ----------------------------------------------------------
classes = (MESH_OT_quick_cleanup_plus, VIEW3D_PT_quick_cleanup_plus)


def register():
    for c in classes:
        bpy.utils.register_class(c)

    bpy.types.Scene.qmc_select_all = bpy.props.BoolProperty(
        name="Select All Vertices",
        default=True,
        description="Disable this if you only want to cleanup manual selection"
    )
    bpy.types.Scene.qmc_merge_vertices = bpy.props.BoolProperty(
        name="Merge Vertices by Distance", default=True)
    bpy.types.Scene.qmc_merge_distance = bpy.props.FloatProperty(
        name="Merge Distance", default=0.0001, min=0.0, step=0.001, precision=5)
    bpy.types.Scene.qmc_tris_to_quads = bpy.props.BoolProperty(
        name="Convert Tris to Quads", default=False)
    bpy.types.Scene.qmc_delete_loose = bpy.props.BoolProperty(
        name="Delete Loose Geometry", default=False)
    bpy.types.Scene.qmc_recalc_normals = bpy.props.BoolProperty(
        name="Recalculate Normals", default=True)
    bpy.types.Scene.qmc_recalc_inside = bpy.props.BoolProperty(
        name="Inside", default=False)
    bpy.types.Scene.qmc_reset_vectors = bpy.props.BoolProperty(
        name="Reset Vectors", default=True)
    bpy.types.Scene.qmc_origin_mode = bpy.props.EnumProperty(
        name="Set Origin",
        items=[
            ('NONE', "Do Nothing", ""),
            ('GEOMETRY', "Geometry to Origin", ""),
            ('OBJECT', "Center of Mass", ""),
        ],
        default='NONE'
    )
    bpy.types.Scene.qmc_shade_mode = bpy.props.EnumProperty(
        name="Shade Mode",
        items=[
            ('NONE', "Do Nothing", ""),
            ('FLAT', "Flat", ""),
            ('SMOOTH', "Smooth", ""),
            ('AUTO', "Auto Smooth", ""),
        ],
        default='NONE'
    )
    bpy.types.Scene.qmc_dissolve_limited = bpy.props.BoolProperty(
        name="Limited Dissolve", default=False)
    bpy.types.Scene.qmc_dissolve_angle = bpy.props.FloatProperty(
        name="Angle Limit (Degrees)", default=5.0, min=0.1, max=180.0, subtype='ANGLE', unit='ROTATION')
    bpy.types.Scene.qmc_view_selected = bpy.props.BoolProperty(
        name="View Selected After Cleanup",
        description="Frame the cleaned objects in the 3D View after cleanup",
        default=False,
    )

    register_keymap()
    print("Quick Cleanup+ Addon Registered.")


def unregister():
    unregister_keymap()

    del bpy.types.Scene.qmc_select_all
    del bpy.types.Scene.qmc_merge_vertices
    del bpy.types.Scene.qmc_merge_distance
    del bpy.types.Scene.qmc_tris_to_quads
    del bpy.types.Scene.qmc_delete_loose
    del bpy.types.Scene.qmc_recalc_normals
    del bpy.types.Scene.qmc_recalc_inside
    del bpy.types.Scene.qmc_reset_vectors
    del bpy.types.Scene.qmc_origin_mode
    del bpy.types.Scene.qmc_shade_mode
    del bpy.types.Scene.qmc_dissolve_limited
    del bpy.types.Scene.qmc_dissolve_angle
    del bpy.types.Scene.qmc_view_selected

    for c in reversed(classes):
        bpy.utils.unregister_class(c)

    print("Quick Cleanup+ Addon Unregistered.")


if __name__ == "__main__":
    register()
