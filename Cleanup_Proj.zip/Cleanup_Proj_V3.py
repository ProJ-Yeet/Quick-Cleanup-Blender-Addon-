bl_info = {
    "name": "Quick Mesh Cleanup+ (All-in-One)",
    "author": "ProJYeet",
    "version": (3, 0),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar > Quick Cleanup+",
    "description": "Batch mesh cleanup with presets, collapsible UI, apply transforms, and faster BMesh ops + debug logs",
    "category": "Mesh",
}

import bpy
import bmesh
import math
import time

DEBUG = True  # Toggle detailed logging
LOG_BUFFER = []


def log(msg):
    if DEBUG:
        entry = f"[QMC+] {msg}"
        LOG_BUFFER.append(entry)
        print(entry)

addon_keymaps = []


def dump_log_to_text_editor():
    if not LOG_BUFFER:
        return
    txt = bpy.data.texts.get("QMC_Log") or bpy.data.texts.new("QMC_Log")
    try:
        txt.clear()
    except Exception:
        # older Blender versions may not have clear()
        while txt.lines:
            txt.lines.remove(txt.lines[0])
    for l in LOG_BUFFER:
        txt.write(l + "\n")


def find_view3d_region_context():
    wm = bpy.context.window_manager
    for window in wm.windows:
        screen = window.screen
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                for region in area.regions:
                    if region.type == 'WINDOW':
                        return window, screen, area, region
    return None, None, None, None


def view_selected_safe(context):
    win, screen, area, region = find_view3d_region_context()
    if not area:
        return False
    with context.temp_override(window=win, screen=screen, area=area, region=region,
                               space=area.spaces.active, scene=context.scene, view_layer=context.view_layer):
        try:
            bpy.ops.view3d.view_selected(use_all_regions=False)
            return True
        except Exception as e:
            log(f"view_selected failed: {e}")
            return False


def apply_transform_flags(obj, apply_loc, apply_rot, apply_scale):
    log(f"Applying transforms to {obj.name}")
    if obj.mode != 'OBJECT':
        try:
            bpy.ops.object.mode_set(mode='OBJECT')
        except Exception as e:
            log(f"Could not set OBJECT mode before transform apply on {obj.name}: {e}")
    bpy.context.view_layer.objects.active = obj
    try:
        bpy.ops.object.transform_apply(location=apply_loc, rotation=apply_rot, scale=apply_scale)
    except Exception as e:
        log(f"Transform apply failed on {obj.name}: {e}")


def apply_modifiers(obj):
    # Apply modifiers in object mode; keep a safe list to avoid problematic modifiers
    log(f"Applying modifiers for {obj.name}")
    if obj.mode != 'OBJECT':
        try:
            bpy.ops.object.mode_set(mode='OBJECT')
        except Exception as e:
            log(f"Could not set OBJECT mode before modifier apply on {obj.name}: {e}")
    bpy.context.view_layer.objects.active = obj
    # copy names as we may remove modifiers as we iterate
    mod_names = [m.name for m in obj.modifiers]
    for mname in mod_names:
        try:
            bpy.ops.object.modifier_apply(modifier=mname)
            log(f"Applied modifier {mname} on {obj.name}")
        except Exception as e:
            log(f"Modifier apply failed on {obj.name} for {mname}: {e}")

def save_custom_preset_from_scene(scene):
    """Copy current scene QMC settings into a stored 'custom' preset slot."""
    scene.qmc_custom_preset_select_all = scene.qmc_select_all
    scene.qmc_custom_preset_merge_vertices = scene.qmc_merge_vertices
    scene.qmc_custom_preset_merge_distance = scene.qmc_merge_distance
    scene.qmc_custom_preset_dissolve_limited = scene.qmc_dissolve_limited
    scene.qmc_custom_preset_dissolve_angle = scene.qmc_dissolve_angle
    scene.qmc_custom_preset_tris_to_quads = scene.qmc_tris_to_quads
    scene.qmc_custom_preset_tris_to_quads_angle = scene.qmc_tris_to_quads_angle
    scene.qmc_custom_preset_delete_loose = scene.qmc_delete_loose
    scene.qmc_custom_preset_fix_non_manifold = scene.qmc_fix_non_manifold
    scene.qmc_custom_preset_recalc_normals = scene.qmc_recalc_normals
    scene.qmc_custom_preset_recalc_inside = scene.qmc_recalc_inside
    scene.qmc_custom_preset_reset_vectors = scene.qmc_reset_vectors
    scene.qmc_custom_preset_origin_mode = scene.qmc_origin_mode
    scene.qmc_custom_preset_shade_mode = scene.qmc_shade_mode
    scene.qmc_custom_preset_auto_smooth_angle = scene.qmc_auto_smooth_angle
    scene.qmc_custom_preset_apply_loc = scene.qmc_apply_loc
    scene.qmc_custom_preset_apply_rot = scene.qmc_apply_rot
    scene.qmc_custom_preset_apply_scale = scene.qmc_apply_scale
    scene.qmc_custom_preset_apply_modifiers = scene.qmc_apply_modifiers
    scene.qmc_custom_preset_decimate_ratio = scene.qmc_decimate_ratio
    scene.qmc_custom_preset_view_selected = scene.qmc_view_selected
    scene.qmc_custom_preset_visible_only = scene.qmc_visible_only


def apply_custom_preset_to_scene(scene):
    """Apply stored 'custom' preset values back to main QMC settings."""
    scene.qmc_select_all = scene.qmc_custom_preset_select_all
    scene.qmc_merge_vertices = scene.qmc_custom_preset_merge_vertices
    scene.qmc_merge_distance = scene.qmc_custom_preset_merge_distance
    scene.qmc_dissolve_limited = scene.qmc_custom_preset_dissolve_limited
    scene.qmc_dissolve_angle = scene.qmc_custom_preset_dissolve_angle
    scene.qmc_tris_to_quads = scene.qmc_custom_preset_tris_to_quads
    scene.qmc_tris_to_quads_angle = scene.qmc_custom_preset_tris_to_quads_angle
    scene.qmc_delete_loose = scene.qmc_custom_preset_delete_loose
    scene.qmc_fix_non_manifold = scene.qmc_custom_preset_fix_non_manifold
    scene.qmc_recalc_normals = scene.qmc_custom_preset_recalc_normals
    scene.qmc_recalc_inside = scene.qmc_custom_preset_recalc_inside
    scene.qmc_reset_vectors = scene.qmc_custom_preset_reset_vectors
    scene.qmc_origin_mode = scene.qmc_custom_preset_origin_mode
    scene.qmc_shade_mode = scene.qmc_custom_preset_shade_mode
    scene.qmc_auto_smooth_angle = scene.qmc_custom_preset_auto_smooth_angle
    scene.qmc_apply_loc = scene.qmc_custom_preset_apply_loc
    scene.qmc_apply_rot = scene.qmc_custom_preset_apply_rot
    scene.qmc_apply_scale = scene.qmc_custom_preset_apply_scale
    scene.qmc_apply_modifiers = scene.qmc_custom_preset_apply_modifiers
    scene.qmc_decimate_ratio = scene.qmc_custom_preset_decimate_ratio
    scene.qmc_view_selected = scene.qmc_custom_preset_view_selected
    scene.qmc_visible_only = scene.qmc_custom_preset_visible_only

def set_preset(scene, preset_name):
    if preset_name == 'GAME':
        # Game-ready preset (unchanged logic)
        scene.qmc_select_all = True
        scene.qmc_merge_vertices = True
        scene.qmc_merge_distance = 0.0008
        scene.qmc_dissolve_limited = False
        scene.qmc_tris_to_quads = True
        scene.qmc_tris_to_quads_angle = 0.174533
        scene.qmc_delete_loose = True
        scene.qmc_recalc_normals = True
        scene.qmc_reset_vectors = True
        scene.qmc_shade_mode = 'AUTO'
        scene.qmc_origin_mode = 'GEOMETRY_TO_ORIGIN'
        scene.qmc_decimate_ratio = 1.0
    elif preset_name == 'CUSTOM':
        apply_custom_preset_to_scene(scene)

class MESH_OT_qmc_preset(bpy.types.Operator):
    bl_idname = "mesh.qmc_preset"
    bl_label = "Apply Mesh Cleanup Preset"
    bl_description = "Apply a cleanup preset configuration"
    preset: bpy.props.StringProperty(default='LIGHT')

    def execute(self, context):
        set_preset(context.scene, self.preset)
        self.report({'INFO'}, f"Preset '{self.preset}' applied.")
        return {'FINISHED'}

class MESH_OT_qmc_save_custom_preset(bpy.types.Operator):
    bl_idname = "mesh.qmc_save_custom_preset"
    bl_label = "Save Custom Preset"
    bl_description = "Save current settings into the Custom preset slot"

    def execute(self, context):
        save_custom_preset_from_scene(context.scene)
        self.report({'INFO'}, "Custom preset saved from current settings.")
        return {'FINISHED'}

class MESH_OT_qmc_reset_vectors(bpy.types.Operator):
    bl_idname = "mesh.qmc_reset_vectors"
    bl_label = "Reset Vectors"
    bl_description = "Run Blender's built-in Reset Vectors on the current selection"

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'

    def execute(self, context):
        obj = context.active_object
        prev_mode = obj.mode

        # Ensure Edit Mode for the mesh normals operator
        if obj.mode != 'EDIT':
            bpy.ops.object.mode_set(mode='EDIT')

        try:
            # This is the same operator as Mesh > Normals > Reset Vectors
            bpy.ops.mesh.normals_tools(mode='RESET')  # Blender's native reset vectors[web:27][web:33]
        except Exception as e:
            self.report({'ERROR'}, f"Reset Vectors failed: {e}")
            return {'CANCELLED'}
        finally:
            # Go back to previous mode
            if prev_mode != obj.mode:
                try:
                    bpy.ops.object.mode_set(mode=prev_mode)
                except Exception:
                    pass

        self.report({'INFO'}, "Reset Vectors applied.")
        return {'FINISHED'}

class MESH_OT_quick_cleanup_all_in_one(bpy.types.Operator):
    bl_idname = "mesh.quick_cleanup_all_in_one"
    bl_label = "Run Quick Cleanup+ (All-in-One)"
    bl_description = "Run batch cleanup on selected mesh objects using BMesh optimizations"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        t0 = time.time()
        scene = context.scene
        sel_objs = [o for o in context.selected_objects if o.type == 'MESH']

        if scene.qmc_visible_only:
            sel_objs = [o for o in sel_objs if o.visible_get()]

        if not sel_objs:
            self.report({'ERROR'}, "No mesh objects selected (or visible).")
            return {'CANCELLED'}

        original_active = context.object
        original_mode = context.mode

        cleaned = 0
        failed = []
        obj_times = []

        wm = context.window_manager
        try:
            wm.progress_begin(0, len(sel_objs))
        except Exception as e:
            log(f"progress_begin failed: {e}")

        for idx, obj in enumerate(sel_objs, 1):
            t_obj = time.time()
            try:
                log(f"--- Cleaning {obj.name} ({idx}/{len(sel_objs)}) ---")

                # ensure unique data if shared
                if obj.data.users > 1:
                    obj.data = obj.data.copy()

                bpy.context.view_layer.objects.active = obj
                obj.select_set(True)

                # Apply modifiers if requested
                if scene.qmc_apply_modifiers:
                    apply_modifiers(obj)

                # Apply transforms if requested
                if scene.qmc_apply_loc or scene.qmc_apply_rot or scene.qmc_apply_scale:
                    apply_transform_flags(obj, scene.qmc_apply_loc, scene.qmc_apply_rot, scene.qmc_apply_scale)

                # Optional decimate via modifier (useful before entering edit mode)
                if scene.qmc_decimate_ratio < 1.0:
                    try:
                        if obj.mode != 'OBJECT':
                            bpy.ops.object.mode_set(mode='OBJECT')
                        dec_mod = obj.modifiers.new(name='QMC_Decimate', type='DECIMATE')
                        dec_mod.ratio = scene.qmc_decimate_ratio
                        bpy.ops.object.modifier_apply(modifier=dec_mod.name)
                        log(f"Applied decimate ({scene.qmc_decimate_ratio}) on {obj.name}")
                    except Exception as e:
                        log(f"Decimate apply failed on {obj.name}: {e}")

                # Enter edit mode (do once per object)
                try:
                    bpy.ops.object.mode_set(mode='EDIT')
                except Exception as e:
                    log(f"Could not enter EDIT mode for {obj.name}: {e}")

                me = obj.data
                bm = bmesh.from_edit_mesh(me)

                # Optional select all (affects operator fallback paths)
                if scene.qmc_select_all:
                    for v in bm.verts:
                        v.select_set(True)

                # Clear custom normals first if requested (important order)
                if scene.qmc_reset_vectors:
                    win, screen, area, region = find_view3d_region_context()
                    if area:
                        with context.temp_override(window=win, screen=screen, area=area, region=region,
                                                   space=area.spaces.active, scene=context.scene, view_layer=context.view_layer):
                            try:
                                bpy.ops.mesh.customdata_custom_splitnormals_clear()
                            except Exception as e:
                                log(f"customdata_custom_splitnormals_clear failed (override): {e}")
                    else:
                        try:
                            bpy.ops.mesh.customdata_custom_splitnormals_clear()
                        except Exception as e:
                            log(f"customdata_custom_splitnormals_clear failed: {e}")

                # Recalculate normals via BMesh (this is robust)
                if scene.qmc_recalc_normals:
                    try:
                        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
                        if scene.qmc_recalc_inside:
                            for f in bm.faces:
                                f.normal_flip()
                        bm.normal_update()
                    except Exception as e:
                        log(f"bmesh recalc_face_normals failed: {e}")

                # Merge vertices (remove doubles) using BMesh for speed
                if scene.qmc_merge_vertices:
                    try:
                        verts_to_merge = [v for v in bm.verts if v.select]
                        if verts_to_merge:
                            try:
                                bmesh.ops.remove_doubles(bm, verts=verts_to_merge, dist=scene.qmc_merge_distance)
                            except Exception as e:
                                log(f"bmesh remove_doubles failed: {e}")
                    except Exception as e:
                        log(f"remove_doubles outer failed: {e}")

                # Fix Non-Manifold (BMesh delete of non-manifold edges)
                if scene.qmc_fix_non_manifold:
                    try:
                        non_manifold_edges = [e for e in bm.edges if not e.is_manifold]
                        if non_manifold_edges:
                            bmesh.ops.delete(bm, geom=non_manifold_edges, context='EDGES')
                            log(f"Deleted {len(non_manifold_edges)} non-manifold edges on {obj.name}")
                    except Exception as e:
                        log(f"Fix non-manifold via bmesh failed: {e}")

                # Dissolve limited - use operator (angle limit is in radians)
                if scene.qmc_dissolve_limited:
                    win, screen, area, region = find_view3d_region_context()
                    if area:
                        with context.temp_override(window=win, screen=screen, area=area, region=region,
                                                   space=area.spaces.active, scene=context.scene, view_layer=context.view_layer):
                            try:
                                bpy.ops.mesh.dissolve_limited(angle_limit=math.radians(scene.qmc_dissolve_angle))
                            except Exception as e:
                                log(f"dissolve_limited operator failed (override): {e}")
                    else:
                        try:
                            bpy.ops.mesh.dissolve_limited(angle_limit=math.radians(scene.qmc_dissolve_angle))
                        except Exception as e:
                            log(f"dissolve_limited operator failed: {e}")

                # Tris -> Quads (use the built-in operator from Face menu exactly as Blender does)
                if scene.qmc_tris_to_quads:
                    log(f"Running built-in Tris to Quads on {obj.name}")
                    win, screen, area, region = find_view3d_region_context()

                    # Ensure object is in Edit Mode (operator only works there)
                    if obj.mode != 'EDIT':
                        bpy.ops.object.mode_set(mode='EDIT')

                    if area:
                        with context.temp_override(
                            window=win,
                            screen=screen,
                            area=area,
                            region=region,
                            space=area.spaces.active,
                            scene=context.scene,
                            view_layer=context.view_layer,
                            active_object=obj,
                            object=obj
                        ):
                            try:
                                bpy.ops.mesh.tris_convert_to_quads()
                                log("Successfully ran tris->quads via override")
                            except Exception as e:
                                log(f"tris_convert_to_quads operator failed (override): {e}")
                    else:
                        try:
                            bpy.ops.mesh.tris_convert_to_quads()
                            log("Successfully ran tris->quads without override")
                        except Exception as e:
                            log(f"tris_convert_to_quads operator failed: {e}")

                    # Optionally return to Object Mode
                    try:
                        bpy.ops.object.mode_set(mode='OBJECT')
                    except Exception as e:
                        log(f"Could not set OBJECT mode after tris->quads for {obj.name}: {e}")

                # Delete loose geometry via BMesh (fast)
                if scene.qmc_delete_loose:
                    try:
                        loose_verts = [v for v in bm.verts if (not v.link_edges and not v.link_faces)]
                        loose_edges = [e for e in bm.edges if not e.link_faces]
                        loose_faces = [f for f in bm.faces if len(f.verts) == 0]
                        to_del = loose_verts + loose_edges + loose_faces
                        if to_del:
                            bmesh.ops.delete(bm, geom=to_del, context='VERTS')
                    except Exception as e:
                        log(f"delete loose via bmesh failed: {e}")
                        win, screen, area, region = find_view3d_region_context()
                        if area:
                            with context.temp_override(window=win, screen=screen, area=area, region=region,
                                                       space=area.spaces.active, scene=context.scene, view_layer=context.view_layer):
                                try:
                                    bpy.ops.mesh.delete_loose()
                                except Exception as ex:
                                    log(f"delete_loose override failed: {ex}")
                        else:
                            try:
                                bpy.ops.mesh.delete_loose()
                            except Exception as ex:
                                log(f"delete_loose failed: {ex}")

                # Finalize BMesh changes
                try:
                    bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
                except Exception as e:
                    log(f"bmesh.update_edit_mesh failed: {e}")

                # Return to object mode to run shading/origin ops
                try:
                    bpy.ops.object.mode_set(mode='OBJECT')
                except Exception as e:
                    log(f"Could not set OBJECT mode after edits for {obj.name}: {e}")

                # ensure active object
                try:
                    bpy.context.view_layer.objects.active = obj
                except Exception as e:
                    log(f"Could not set active object before shading: {e}")

                # -------- SHADING (patched to use v2.3 behaviour + robust checks) --------
                try:
                    # Ensure we're in OBJECT mode for shading ops (this matches your old addon's working flow)
                    if obj.mode != 'OBJECT':
                        try:
                            bpy.ops.object.mode_set(mode='OBJECT')
                        except Exception as e:
                            log(f"Failed to set OBJECT mode before shading for {obj.name}: {e}")

                    shade_mode = scene.qmc_shade_mode
                    mesh = obj.data

                    if shade_mode == 'SMOOTH':
                        # call operator (works in OBJECT mode) - this reliably updates viewport shading
                        try:
                            bpy.ops.object.shade_smooth()
                        except Exception as e:
                            log(f"shade_smooth operator failed for {obj.name}: {e}")
                        # also set mesh data where appropriate
                        for mod in obj.modifiers:
                            if mod.type == 'SMOOTH_BY_ANGLE':
                                obj.modifiers.remove(mod)
                        if hasattr(mesh, "use_auto_smooth"):
                            mesh.use_auto_smooth = False

                    elif shade_mode == 'FLAT':
                        try:
                            bpy.ops.object.shade_flat()
                        except Exception as e:
                            log(f"shade_flat operator failed for {obj.name}: {e}")
                        for mod in obj.modifiers:
                            if mod.type == 'SMOOTH_BY_ANGLE':
                                obj.modifiers.remove(mod)
                        if hasattr(mesh, "use_auto_smooth"):
                            mesh.use_auto_smooth = False

                    elif shade_mode == 'AUTO':
                        # Use Blender's built-in "Shade Auto Smooth" operator
                        try:
                            bpy.ops.object.shade_auto_smooth()
                        except Exception as e:
                            log(f"shade_auto_smooth operator failed for {obj.name}: {e}")

                except Exception as e:
                    log(f"Shading ops failed for {obj.name}: {e}")

                # -------- ORIGIN --------
                try:
                    if scene.qmc_origin_mode != 'NONE':
                        if scene.qmc_origin_mode == 'GEOMETRY_TO_ORIGIN':
                            obj.location = (0.0, 0.0, 0.0)
                        elif scene.qmc_origin_mode == 'ORIGIN_TO_GEOMETRY':
                            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
                        elif scene.qmc_origin_mode == 'ORIGIN_TO_CURSOR':
                            bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
                        elif scene.qmc_origin_mode == 'ORIGIN_TO_COM_VOLUME':
                            bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS', center='VOLUME')
                        elif scene.qmc_origin_mode == 'ORIGIN_TO_COM_SURFACE':
                            bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS', center='SURFACE')
                except Exception as e:
                    log(f"Origin error for {obj.name}: {e}")

                cleaned += 1

            except Exception as e:
                log(f"Error cleaning object {obj.name}: {e}")
                failed.append(obj.name)
                try:
                    bpy.ops.object.mode_set(mode='OBJECT')
                except Exception as ex:
                    log(f"Failed to ensure OBJECT mode after error for {obj.name}: {ex}")

            # update progress
            try:
                wm.progress_update(idx)
            except Exception as e:
                log(f"progress_update failed: {e}")
            try:
                bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
            except Exception:
                pass

            obj_times.append(time.time() - t_obj)

        try:
            wm.progress_end()
        except Exception as e:
            log(f"progress_end failed: {e}")

        # restore selection & active
        try:
            bpy.ops.object.select_all(action='DESELECT')
        except Exception as e:
            log(f"select_all deselect failed: {e}")

        for o in sel_objs:
            try:
                o.select_set(True)
            except Exception as e:
                log(f"Could not re-select {o.name}: {e}")

        if original_active:
            try:
                bpy.context.view_layer.objects.active = original_active
            except Exception as e:
                log(f"Could not restore original active object: {e}")

        # restore mode
        try:
            if original_mode and isinstance(original_mode, str) and original_mode.startswith('EDIT_'):
                bpy.ops.object.mode_set(mode='EDIT')
            else:
                bpy.ops.object.mode_set(mode=original_mode)
        except Exception as e:
            log(f"Could not restore original mode '{original_mode}': {e}")

        # View selected if requested
        if scene.qmc_view_selected:
            ok = view_selected_safe(context)
            if not ok:
                log("view_selected: no VIEW_3D context found.")

        dt = time.time() - t0
        summary = f"Quick Cleanup+ finished. Cleaned {cleaned}/{len(sel_objs)} in {dt:.2f}s"
        if failed:
            summary += f" | Failed: {', '.join(failed)}"
        log(summary)

        # Stats
        if obj_times:
            try:
                import statistics
                log(f"Avg per-object time: {statistics.mean(obj_times):.4f}s")
                log(f"Slowest object: {max(obj_times):.4f}s")
            except Exception:
                pass

        # Dump log to text editor if debug
        if DEBUG:
            try:
                dump_log_to_text_editor()
                log("Dumped log to Text Editor (QMC_Log)")
            except Exception as e:
                log(f"Failed to dump log to text editor: {e}")

        self.report({'INFO'}, summary)
        return {'FINISHED'}


class VIEW3D_PT_quick_cleanup_panel(bpy.types.Panel):
    bl_label = "Quick Mesh Cleanup+ (All-in-One)"
    bl_idname = "VIEW3D_PT_quick_cleanup_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Quick Cleanup+'

    def draw(self, context):
        scene = context.scene
        layout = self.layout

        # Presets row
        layout.label(text="Presets:")
        row = layout.row(align=True)
        row.operator("mesh.qmc_preset", text="Game-Ready").preset = 'GAME'
        
        # Custom preset + Save
        row = layout.row(align=True)
        row.operator("mesh.qmc_preset", text="Custom").preset = 'CUSTOM'
        row.operator("mesh.qmc_save_custom_preset", text="Save")

        layout.separator()

        # Topology collapsible
        icon = 'TRIA_DOWN' if scene.qmc_ui_show_topology else 'TRIA_RIGHT'
        layout.prop(scene, "qmc_ui_show_topology", icon=icon, emboss=False)
        if scene.qmc_ui_show_topology:
            box = layout.box()
            col = box.column(align=True)
            col.prop(scene, "qmc_select_all")
            col.prop(scene, "qmc_merge_vertices")
            if scene.qmc_merge_vertices:
                col.prop(scene, "qmc_merge_distance")
            col.prop(scene, "qmc_dissolve_limited")
            if scene.qmc_dissolve_limited:
                col.prop(scene, "qmc_dissolve_angle")
            col.prop(scene, "qmc_tris_to_quads")
            if scene.qmc_tris_to_quads:
                col.prop(scene, "qmc_tris_to_quads_angle")
            col.prop(scene, "qmc_delete_loose")
            col.prop(scene, "qmc_reset_vectors", text="Reset Vectors")
            col.prop(scene, "qmc_fix_non_manifold", text="Fix Non-Manifold")

        # Normals/Data collapsible
        icon = 'TRIA_DOWN' if scene.qmc_ui_show_normals else 'TRIA_RIGHT'
        layout.prop(scene, "qmc_ui_show_normals", icon=icon, emboss=False)
        if scene.qmc_ui_show_normals:
            box = layout.box()
            col = box.column(align=True)
            col.prop(scene, "qmc_recalc_normals")
            if scene.qmc_recalc_normals:
                col.prop(scene, "qmc_recalc_inside", text="Recalculate Inside (flip normals)")
            col.prop(scene, "qmc_reset_vectors", text="Clear custom split normals")

        # Shading / Origin collapsible
        icon = 'TRIA_DOWN' if scene.qmc_ui_show_shading else 'TRIA_RIGHT'
        layout.prop(scene, "qmc_ui_show_shading", icon=icon, emboss=False)
        if scene.qmc_ui_show_shading:
            box = layout.box()
            col = box.column(align=True)
            col.prop(scene, "qmc_origin_mode", text="Set Origin")
            col.prop(scene, "qmc_shade_mode", text="Shade Mode")
            if scene.qmc_shade_mode == 'AUTO':
                col.prop(scene, "qmc_auto_smooth_angle", text="Auto Smooth Angle (rad)")

        # Advanced collapsible
        icon = 'TRIA_DOWN' if scene.qmc_ui_show_advanced else 'TRIA_RIGHT'
        layout.prop(scene, "qmc_ui_show_advanced", icon=icon, emboss=False)
        if scene.qmc_ui_show_advanced:
            box = layout.box()
            col = box.column(align=True)
            col.label(text="Apply Transformations before cleanup:")
            col.prop(scene, "qmc_apply_loc", text="Location")
            col.prop(scene, "qmc_apply_rot", text="Rotation")
            col.prop(scene, "qmc_apply_scale", text="Scale")
            col.prop(scene, "qmc_apply_modifiers", text="Apply Modifiers Before Cleanup")
            col.prop(scene, "qmc_decimate_ratio", text="Decimate Ratio (1.0=no)")
            col.separator()
            col.prop(scene, "qmc_view_selected", text="Frame cleaned objects after cleanup")
            col.prop(scene, "qmc_visible_only", text="Only Cleanup Visible Objects")

        layout.separator()
        layout.operator("mesh.quick_cleanup_all_in_one", icon='CHECKMARK')
        layout.label(text="Shortcut: Alt + Ctrl + Q")


classes = (
    MESH_OT_qmc_preset,
    MESH_OT_qmc_save_custom_preset,
    MESH_OT_qmc_reset_vectors,
    MESH_OT_quick_cleanup_all_in_one,
    VIEW3D_PT_quick_cleanup_panel,
)


def register_keymap():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if not kc:
        return
    try:
        km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
        kmi = km.keymap_items.new("mesh.quick_cleanup_all_in_one", 'Q', 'PRESS', alt=True, ctrl=True)
        addon_keymaps.append((km, kmi))
    except Exception as e:
        log(f"register_keymap failed: {e}")


def unregister_keymap():
    for km, kmi in addon_keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception as e:
            log(f"unregister_keymap removal failed: {e}")
    addon_keymaps.clear()

QMC_ORIGIN_MODE_ITEMS = [
    ('NONE',                 "Do Nothing",                         ""),
    ('GEOMETRY_TO_ORIGIN',   "Geometry to Origin",                 "Move geometry to world origin (sets object location to 0,0,0)"),
    ('ORIGIN_TO_GEOMETRY',   "Origin to Geometry",                 "Move origin to geometry center"),
    ('ORIGIN_TO_CURSOR',     "Origin to 3D Cursor",                "Set origin to 3D cursor"),
    ('ORIGIN_TO_COM_VOLUME', "Origin to Center of Mass (Volume)",  "Use volume center for origin position"),
    ('ORIGIN_TO_COM_SURFACE',"Origin to Center of Mass (Surface)", "Use surface center for origin position"),
]

QMC_SHADE_MODE_ITEMS = [
    ('NONE',   "Do Nothing",   ""),
    ('FLAT',   "Flat",         ""),
    ('SMOOTH', "Smooth",       ""),
    ('AUTO',   "Auto Smooth",  ""),
]

def register():
    for c in classes:
        bpy.utils.register_class(c)

    # UI collapsible toggles
    bpy.types.Scene.qmc_ui_show_topology = bpy.props.BoolProperty(name="Topology", default=True)
    bpy.types.Scene.qmc_ui_show_normals = bpy.props.BoolProperty(name="Normals / Data", default=True)
    bpy.types.Scene.qmc_ui_show_shading = bpy.props.BoolProperty(name="Shading / Origin", default=True)
    bpy.types.Scene.qmc_ui_show_advanced = bpy.props.BoolProperty(name="Advanced", default=False)

    # Core options
    bpy.types.Scene.qmc_select_all = bpy.props.BoolProperty(
        name="Select All Vertices",
        default=True,
        description="Disable this if you only want to cleanup a manual selection"
    )
    bpy.types.Scene.qmc_merge_vertices = bpy.props.BoolProperty(
        name="Merge Vertices by Distance",
        default=True,
        description="Merge vertices within the Merge Distance"
    )
    bpy.types.Scene.qmc_merge_distance = bpy.props.FloatProperty(
        name="Merge Distance",
        default=0.0001, min=0.0, step=0.001, precision=6,
        description="Distance threshold to merge vertices (in Blender units)"
    )
    bpy.types.Scene.qmc_dissolve_limited = bpy.props.BoolProperty(
        name="Limited Dissolve",
        default=False,
        description="Perform angle-based limited dissolve"
    )
    bpy.types.Scene.qmc_dissolve_angle = bpy.props.FloatProperty(
        name="Angle Limit (Degrees)",
        default=5.0, min=0.1, max=180.0,
        description="Angle limit for limited dissolve (degrees)"
    )
    bpy.types.Scene.qmc_tris_to_quads = bpy.props.BoolProperty(
        name="Convert Tris to Quads",
        default=False,
        description="Attempt to convert triangles to quads"
    )
    bpy.types.Scene.qmc_tris_to_quads_angle = bpy.props.FloatProperty(
        name="Tris->Quads Angle (radians)",
        default=0.174533,  # ~10 degrees
        description="Angle threshold for joining triangles (radians)"
    )
    bpy.types.Scene.qmc_delete_loose = bpy.props.BoolProperty(
        name="Delete Loose Geometry",
        default=False,
        description="Remove loose verts/edges that aren't connected to faces"
    )

    # Normals / split normals
    bpy.types.Scene.qmc_recalc_normals = bpy.props.BoolProperty(
        name="Recalculate Normals",
        default=True,
        description="Recalculate face normals (bmesh-based)"
    )
    bpy.types.Scene.qmc_recalc_inside = bpy.props.BoolProperty(
        name="Recalculate Inside (flip)",
        default=False,
        description="Flip normals to point inside after recalculation"
    )
    bpy.types.Scene.qmc_reset_vectors = bpy.props.BoolProperty(
        name="Clear custom split normals",
        default=True,
        description="Clear custom split normals (custom normals) before recalculation"
    )

    # Shading / origin
    bpy.types.Scene.qmc_origin_mode = bpy.props.EnumProperty(
        name="Set Origin",
        items=QMC_ORIGIN_MODE_ITEMS,
        default='NONE'
    )

    bpy.types.Scene.qmc_shade_mode = bpy.props.EnumProperty(
        name="Shade Mode",
        items=QMC_SHADE_MODE_ITEMS,
        default='NONE',
        description="Shading mode to set after cleanup"
    )

    bpy.types.Scene.qmc_auto_smooth_angle = bpy.props.FloatProperty(
        name="Auto Smooth Angle (rad)",
        default=1.0472,
        description="Auto Smooth angle used when Shade Mode = AUTO"
    )

    # Advanced / transforms / view
    bpy.types.Scene.qmc_apply_loc = bpy.props.BoolProperty(name="Apply Location", default=False)
    bpy.types.Scene.qmc_apply_rot = bpy.props.BoolProperty(name="Apply Rotation", default=False)
    bpy.types.Scene.qmc_apply_scale = bpy.props.BoolProperty(name="Apply Scale", default=False)
    bpy.types.Scene.qmc_apply_modifiers = bpy.props.BoolProperty(name="Apply Modifiers Before Cleanup", default=False)
    bpy.types.Scene.qmc_view_selected = bpy.props.BoolProperty(
        name="View Selected After Cleanup",
        default=False,
        description="Frame cleaned objects in the 3D View after cleanup"
    )

    # New: Fix non-manifold
    bpy.types.Scene.qmc_fix_non_manifold = bpy.props.BoolProperty(
        name="Fix Non-Manifold",
        default=False,
        description="Attempt to delete non-manifold edges"
    )

    # New: Decimate ratio
    bpy.types.Scene.qmc_decimate_ratio = bpy.props.FloatProperty(
        name="Decimate Ratio",
        default=1.0, min=0.0, max=1.0,
        description="If <1.0, apply Decimate (Collapse) by this ratio before cleanup"
    )

    # New: Only cleanup visible objects
    bpy.types.Scene.qmc_visible_only = bpy.props.BoolProperty(
        name="Only Cleanup Visible Objects",
        default=False,
        description="Only process objects that are currently visible in the viewport"
    )

    # --- NEW: custom preset storage props ------------------------
    bpy.types.Scene.qmc_custom_preset_select_all = bpy.props.BoolProperty(default=True)
    bpy.types.Scene.qmc_custom_preset_merge_vertices = bpy.props.BoolProperty(default=True)
    bpy.types.Scene.qmc_custom_preset_merge_distance = bpy.props.FloatProperty(default=0.0001)
    bpy.types.Scene.qmc_custom_preset_dissolve_limited = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.qmc_custom_preset_dissolve_angle = bpy.props.FloatProperty(default=5.0)
    bpy.types.Scene.qmc_custom_preset_tris_to_quads = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.qmc_custom_preset_tris_to_quads_angle = bpy.props.FloatProperty(default=0.174533)
    bpy.types.Scene.qmc_custom_preset_delete_loose = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.qmc_custom_preset_fix_non_manifold = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.qmc_custom_preset_recalc_normals = bpy.props.BoolProperty(default=True)
    bpy.types.Scene.qmc_custom_preset_recalc_inside = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.qmc_custom_preset_reset_vectors = bpy.props.BoolProperty(default=True)
    bpy.types.Scene.qmc_custom_preset_origin_mode = bpy.props.EnumProperty(
        items=QMC_ORIGIN_MODE_ITEMS,
        default='NONE'
    )
    bpy.types.Scene.qmc_custom_preset_shade_mode = bpy.props.EnumProperty(
        items=QMC_SHADE_MODE_ITEMS,
        default='NONE'
    )
    bpy.types.Scene.qmc_custom_preset_auto_smooth_angle = bpy.props.FloatProperty(default=1.0472)
    bpy.types.Scene.qmc_custom_preset_apply_loc = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.qmc_custom_preset_apply_rot = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.qmc_custom_preset_apply_scale = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.qmc_custom_preset_apply_modifiers = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.qmc_custom_preset_decimate_ratio = bpy.props.FloatProperty(default=1.0)
    bpy.types.Scene.qmc_custom_preset_view_selected = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.qmc_custom_preset_visible_only = bpy.props.BoolProperty(default=False)


    register_keymap()
    log("Quick Mesh Cleanup+ (All-in-One) registered.")


def unregister():
    unregister_keymap()

    prefs = [
        "qmc_ui_show_topology", "qmc_ui_show_normals", "qmc_ui_show_shading", "qmc_ui_show_advanced",
        "qmc_select_all", "qmc_merge_vertices", "qmc_merge_distance",
        "qmc_dissolve_limited", "qmc_dissolve_angle", "qmc_tris_to_quads", "qmc_tris_to_quads_angle",
        "qmc_delete_loose", "qmc_recalc_normals", "qmc_recalc_inside", "qmc_reset_vectors",
        "qmc_origin_mode", "qmc_shade_mode", "qmc_auto_smooth_angle",
        "qmc_apply_loc", "qmc_apply_rot", "qmc_apply_scale", "qmc_view_selected",
        "qmc_apply_modifiers", "qmc_fix_non_manifold", "qmc_decimate_ratio", "qmc_visible_only",
        "qmc_custom_preset_select_all", "qmc_custom_preset_merge_vertices",
        "qmc_custom_preset_merge_distance", "qmc_custom_preset_dissolve_limited",
        "qmc_custom_preset_dissolve_angle", "qmc_custom_preset_tris_to_quads",
        "qmc_custom_preset_tris_to_quads_angle", "qmc_custom_preset_delete_loose",
        "qmc_custom_preset_fix_non_manifold", "qmc_custom_preset_recalc_normals",
        "qmc_custom_preset_recalc_inside", "qmc_custom_preset_reset_vectors",
        "qmc_custom_preset_origin_mode", "qmc_custom_preset_shade_mode",
        "qmc_custom_preset_auto_smooth_angle", "qmc_custom_preset_apply_loc",
        "qmc_custom_preset_apply_rot", "qmc_custom_preset_apply_scale",
        "qmc_custom_preset_apply_modifiers", "qmc_custom_preset_decimate_ratio",
        "qmc_custom_preset_view_selected", "qmc_custom_preset_visible_only",
    ]
    for p in prefs:
        if hasattr(bpy.types.Scene, p):
            try:
                delattr(bpy.types.Scene, p)
            except Exception as e:
                log(f"Failed to delete scene prop {p}: {e}")

    for c in reversed(classes):
        try:
            bpy.utils.unregister_class(c)
        except Exception as e:
            log(f"Failed to unregister class {c}: {e}")

    log("Quick Mesh Cleanup+ (All-in-One) unregistered.")


if __name__ == "__main__":
    register()
